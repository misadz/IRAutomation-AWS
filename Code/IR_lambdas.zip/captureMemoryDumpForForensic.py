# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    accountID = event['accountId']
    instanceID = event['instanceID']
    sts = boto3.client('sts')
    credentials = sts.assume_role(RoleArn='arn:aws:iam::'+ accountID +':role/Role_for_Nginx_Web_App_Instance', RoleSessionName = "RoleSession1")['Credentials']
    ACCESS_KEY = credentials['AccessKeyId']
    SECRET_KEY = credentials['SecretAccessKey']
    SESSION_TOKEN = credentials['SessionToken']

    ssmclient = boto3.client(
        'ssm',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
    )

    S3BucketName = os.environ['OUTPUT_S3_BUCKETNAME']
    S3BucketRegion = os.environ['OUTPUT_S3_BUCKETREGION']
    commands = ['#!/bin/bash',
                'sudo mkdir /forensics',
                'sudo yum install git -y',
                'sudo yum install kernel-devel-$(uname -r) -y',
                'sudo yum install gcc -y',
                'sudo git clone https://github.com/504ensicsLabs/LiME /opt/LiME',
                'cd /opt/LiME/src',
                'make',
                'sudo insmod /opt/LiME/src/lime-`uname -r`.ko "path=/forensics/' + instanceID + '-memory.lime format=lime"'
                ]
    
    response = ssmclient.send_command(
            InstanceIds= [instanceID],
            DocumentName='AWS-RunShellScript',
            Parameters={
            'commands': commands,
            'executionTimeout': ['900'] # Seconds all commands have to complete in
            },
            Comment='SSM Command Execution',
            # sydney-summit-incident-response
            OutputS3Region=S3BucketRegion,
            OutputS3BucketName=S3BucketName,
            OutputS3KeyPrefix="incident-response/" + event.get('instanceID')

        )
    logger.info(response)

    # Retrieve the Command ID
    event['commandID'] = response['Command']['CommandId']
    event['command_to_check'] = "MemoryDump"
    return event
