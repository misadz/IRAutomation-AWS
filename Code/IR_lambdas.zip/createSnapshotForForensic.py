
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging
import time

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # TODO implement
    logging.info(event)

    accountID = event.get('accountId')
    instanceID = event.get('instanceID')
    sts = boto3.client('sts')
    credentials = sts.assume_role(RoleArn='arn:aws:iam::'+ accountID +':role/Role_for_Nginx_Web_App_Instance', RoleSessionName = "RoleSession1")['Credentials']
    
    ACCESS_KEY = credentials['AccessKeyId']
    SECRET_KEY = credentials['SecretAccessKey']
    SESSION_TOKEN = credentials['SessionToken']

    ssmclient = boto3.client(
        'ec2',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
    )
    
    ssmclient2 = boto3.resource(
        'ec2',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
    )

    response = ssmclient.describe_instances(

        InstanceIds=[
            instanceID
        ]
    )
    volumeID = response['Reservations'][0]['Instances'][0]['BlockDeviceMappings'][0]['Ebs']['VolumeId']
    logging.info(volumeID)
    SnapShotDetails = ssmclient.create_snapshot(
        Description='Isolated Instance Snapshot',
        VolumeId=volumeID
    )

    logging.info(response)
    logging.info(SnapShotDetails['SnapshotId'])

    waiter = ssmclient.get_waiter('snapshot_completed')
    waiter.wait(
        SnapshotIds=[
            SnapShotDetails['SnapshotId'],
        ]
    )
    snapshotId = SnapShotDetails['SnapshotId']
    account_id = boto3.client("sts").get_caller_identity()["Account"]
    snapshot = ssmclient2.Snapshot(snapshotId)
    response = snapshot.modify_attribute(
        Attribute='createVolumePermission',
        OperationType='add',
        UserIds=[account_id]
    )
    print('response=', response)

    conn = boto3.client('ec2', region_name='ap-northeast-2')
    copy_response = conn.copy_snapshot(
        DestinationRegion='ap-northeast-2',
        SourceRegion='ap-northeast-2',
        SourceSnapshotId=SnapShotDetails['SnapshotId']
    )
    event['SnapshotId'] = SnapShotDetails['SnapshotId']
    return SnapShotDetails['SnapshotId']
