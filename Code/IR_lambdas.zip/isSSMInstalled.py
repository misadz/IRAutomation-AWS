
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import logging

ssmclient = boto3.client('ssm')
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    # Validates whetehr SSM is installed or not
    response = ssmclient.describe_instance_information()
    logging.info(response)
    isSSMInstalled = False

    for item in response['InstanceInformationList']:
    		if item['InstanceId'] == event['ForensicInstanceId']:
    		    isSSMInstalled = True
    		    event['SSM_STATUS'] = 'SUCCEEDED'


    event['stauscheck'] = 1
    return event
