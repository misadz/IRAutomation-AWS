
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import logging
import json
ec2client = boto3.client('ec2')

logger = logging.getLogger()
logger.setLevel(logging.INFO)


# Isolate the instance from the network
def lambda_handler(event, context):

    accountID = event['accountId']
    instanceID = event['instanceID']
    sts = boto3.client('sts')
    credentials = sts.assume_role(RoleArn='arn:aws:iam::'+ accountID +':role/Role_for_Nginx_Web_App_Instance', RoleSessionName = "RoleSession1")['Credentials']
    ACCESS_KEY = credentials['AccessKeyId']
    SECRET_KEY = credentials['SecretAccessKey']
    SESSION_TOKEN = credentials['SessionToken']

    ssmclient = boto3.client(
        'ec2',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
        )

    # instanceID = event.get('instanceID')
    response = ssmclient.describe_instance_status(
        InstanceIds=[
            instanceID,
        ],
        IncludeAllInstances=True
    )
    logger.info("Checking the status of the isolated instance " + instanceID)
    logger.info("The response of the describe_instance_status API is: " + json.dumps(response))
    if len (response['InstanceStatuses']) == 1:
        # There should only be one instance
        event['INSTANCE_STATUS'] = response['InstanceStatuses'][0]['InstanceState']['Name']
    else:
        logger.info("There was issue checking the status of the instance " + instanceID + ". Check the response of the describe_instance_status API call.")
        event['INSTANCE_STATUS'] = "failed to retrieve instance status"
    return event
