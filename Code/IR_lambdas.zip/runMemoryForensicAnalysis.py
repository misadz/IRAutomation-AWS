
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ssmclient = boto3.client('ssm')

def lambda_handler(event, context):
    
    
    instanceID = event['instanceID']
    S3BucketName = os.environ['OUTPUT_S3_BUCKETNAME']
    S3BucketRegion = os.environ['OUTPUT_S3_BUCKETREGION']
    commands = ['#!/bin/bash',
                'printf -v date "%(%F)T" -1',
                'sudo -s',
                'EC2_INSTANCE_ID=$(ec2-metadata --instance-id)',
                'KERNEL_VERSION=$(uname -r)',
                'KERNEL_VERSION_STR=$(uname -r | tr "." "_")',
                'aws s3 cp /mnt2/forensics/' + instanceID + '-memory.lime s3://' + S3BucketName + '/incident-response/' + instanceID + '/' + instanceID + '-memory.lime',
                'cd /opt/volatility',
                'python vol.py -f /mnt2/forensics/' + instanceID + '-memory.lime --profile=ec2-user-${KERNEL_VERSION_STR}x64 linux_psscan > /home/ec2-user/' + instanceID + '-psscan.txt',
                'aws s3 cp /home/ec2-user/' + instanceID + '-psscan.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-psscan.txt',
                'python vol.py -f /mnt2/forensics/' + instanceID + '-memory.lime --profile=ec2-user-${KERNEL_VERSION_STR}x64 linux_pslist > /home/ec2-user/' + instanceID + '-pslist.txt',
                'aws s3 cp /home/ec2-user/' + instanceID + '-pslist.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-pslist.txt',
                'python vol.py -f /mnt2/forensics/' + instanceID + '-memory.lime --profile=ec2-user-${KERNEL_VERSION_STR}x64 linux_pstree > /home/ec2-user/' + instanceID + '-pstree.txt',
                'aws s3 cp /home/ec2-user/' + instanceID + '-pstree.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-pstree.txt'
                ]
    
    
    response = ssmclient.send_command(
            InstanceIds= [event.get('ForensicInstanceId')],
            DocumentName='AWS-RunShellScript',
            Parameters={
            'commands': commands,
            'executionTimeout': ['900'] # Seconds all commands have to complete in
            },
            Comment='SSM Command Execution',
            # sydney-summit-incident-response
            OutputS3Region=S3BucketRegion,
            OutputS3BucketName=S3BucketName,
            OutputS3KeyPrefix="incident-response/" + event.get('ForensicInstanceId')

        )
    logging.info(response)
    # Retrieve the Command ID
    event['commandID'] = response['Command']['CommandId']
    event['command_to_check'] = "MemoryForensicAnalysis"
    return event
