
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ssmclient = boto3.client('ssm')

def lambda_handler(event, context):

    instanceID = event['instanceID']
    S3BucketName = os.environ['OUTPUT_S3_BUCKETNAME']
    S3BucketRegion = os.environ['OUTPUT_S3_BUCKETREGION']
    commands = ['#!/bin/bash',
                'printf -v date "%(%F)T" -1',
                'sudo -i',
                'mkdir /forensics',
                'dd if=/dev/nvme1n1p1 of=/forensics/i-snapshot.dd',
                'sudo mkdir -p /mnt2',
                'mount -o nouuid /dev/nvme1n1p1 /mnt2',
                'fls -r -m -i /forensics/i-snapshot.dd >/home/ec2-user/file-full-i-snapshot.txt',
                'mactime -b /home/ec2-user/file-full-i-snapshot.txt $date >/home/ec2-user/file-2021-i-snapshot.txt',
                'fls -rd /forensics/i-snapshot.dd >/home/ec2-user/file-deleted-i-snapshot.txt',
                'find / -name "*.php" -exec grep -PHn "passthru|@eval|$pass|str_replace" {} \; > /home/ec2-user/webshellfind.txt',
                'find / -name "*.php" -exec grep -PHn "passthru|@eval|$pass|eval(|str_replace)" {} \; > /home/ec2-user/webshellfind_2.txt',
                'strace -e trace=open ps > /home/ec2-user/strace.txt',
                'cp /home/ec2-user/file-deleted-i-snapshot.txt /home/ec2-user/file-deleted' + instanceID + '.txt',
                'cp /home/ec2-user/file-2021-i-snapshot.txt /home/ec2-user/file-2021-i-snapshot.txt',
                'cp /home/ec2-user/file-full-i-snapshot.txt /home/ec2-user/file-full-i-snapshot.txt',
                'aws s3 cp /forensics/i-snapshot.dd s3://' + S3BucketName + '/incident-response/' + instanceID + '/full-file-system.dd',
                'aws s3 cp /home/ec2-user/file-full-i-snapshot.txt s3://' + S3BucketName + '/incident-response/' + instanceID + '/file-full.txt',
                'aws s3 cp /home/ec2-user/file-deleted' + instanceID + '.txt s3://' + S3BucketName + '/incident-response/' + instanceID + '/file-deleted-' + instanceID + '.txt',
                'aws s3 cp /home/ec2-user/file-2021-i-snapshot.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/file-2021-i-snapshot.txt',
                'aws s3 cp /home/ec2-user/webshellfind.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-webshellfind.txt',
                'aws s3 cp /home/ec2-user/webshellfind_2.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-webshellfind_2.txt',
                'aws s3 cp /home/ec2-user/strace.txt s3://' + S3BucketName +'/incident-response/' + instanceID + '/' + instanceID + '-strace.txt',
                ]


    response = ssmclient.send_command(
            InstanceIds= [event.get('ForensicInstanceId')],
            DocumentName='AWS-RunShellScript',
            Parameters={
            'commands': commands,
            'executionTimeout': ['1200'] # Seconds all commands have to complete in
            },
            Comment='SSM Command Execution',
            # sydney-summit-incident-response
            OutputS3Region=S3BucketRegion,
            OutputS3BucketName=S3BucketName,
            OutputS3KeyPrefix="incident-response/" + event.get('ForensicInstanceId')

        )
    logging.info(response)
    # Retrieve the Command ID
    event['commandID'] = response['Command']['CommandId']
    event['command_to_check'] = "SnapshotForensicAnalysis"
    return event
