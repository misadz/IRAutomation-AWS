
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ec2client = boto3.client('ec2')

def lambda_handler(event, context):

    #Create Instances 
    response = ec2client.run_instances(
            BlockDeviceMappings=[
                {
                    'DeviceName': '/dev/xvda',
                    'Ebs': {
                        'DeleteOnTermination': True,
                        'VolumeSize': 12,
                        'VolumeType': 'gp2',
                        'Encrypted': False
                    }
                }
            ],
            ImageId=os.environ['AMI_ID'],
            InstanceType=os.environ['INSTANCE_TYPE'],
            MaxCount=1,
            MinCount=1,
            Monitoring={
                'Enabled': True
            },

            IamInstanceProfile={
                'Arn': os.environ['INSTANCE_PROFILE_ARN']
            },
            #UserData = "#!/bin/bash \n export instancehostname=$(hostname) \n sudo sed -i -e 's/127.0.0.1 localhost/127.0.0.1 localhost '$instancehostname'/g' /etc/hosts \n mkdir /tmp/ssm \n cd /tmp/ssm \n wget https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent/latest/debian_amd64/amazon-ssm-agent.deb \n sudo dpkg -i amazon-ssm-agent.deb \n sudo systemctl enable amazon-ssm-agent \n sudo systemctl start amazon-ssm-agent \n",
            UserData ="""#!/bin/bash \n
                        cd /tmp \n
                        sudo systemctl start amazon-ssm-agent \n
                        sudo yum install -y https://s3.amazonaws.com/ec2-downloads-windows/SSMAgent/latest/linux_amd64/amazon-ssm-agent.rpm \n
                        KERNEL_VERSION=$(uname -r) \n
                        sudo yum install -y kernel-devel \n
                        sudo yum install -y libdwarf-tools \n
                        sudo yum install -y pcregrep libpcre++-dev python-dev python-pip \n
                        sudo pip install --upgrade pip \n
                        pip install distorm3 PyCrypto ujson  \n
                        sudo yum install -y git \n
                        sudo yum -y install https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm \n
                        sudo amazon-linux-extras install -y epel \n
                        sudo yum install -y sleuthkit \n
                        sudo yum install -y python3 \n
                        cd /tmp/ \n
                        curl https://bootstrap.pypa.io/get-pip.py -o get-pip.py \n
                        python3 get-pip.py \n
                        git clone https://github.com/volatilityfoundation/volatility.git /opt/volatility \n
                        cd /opt/volatility \n
                        python setup.py install \n
                        cd /opt/volatility/tools/linux \n
                        make \n
                        zip /opt/volatility/volatility/plugins/overlays/awslinux-${KERNEL_VERSION}.zip /opt/volatility/tools/linux/module.dwarf /boot/System.map-${KERNEL_VERSION} \n""",
            KeyName = os.environ['EC2_KEYPAIR'],
            NetworkInterfaces = [
                {
                    'AssociatePublicIpAddress': True,
                    'DeviceIndex': 0,
                    'SubnetId': os.environ['SUBNET_ID'],
                    'Groups': [
                        os.environ['FORENSIC_SECUTRITYGROUP'],
                    ],
                }
            ],
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {
                            'Key': 'Name',
                            'Value': os.environ['TAG_PROJECT'] + '_InstanceUnderForensics'
                        },{
                            'Key': 'Owner',
                            'Value': os.environ['TAG_OWNER']
                        },{
                            'Key': 'Project',
                            'Value': os.environ['TAG_PROJECT']
                        },{
                            'Key': 'IsInstanceTested',
                            'Value': 'Yes'
                        },
                    ]
                },
            ]
    )
    logging.info(response['Instances'][0]['Placement']['AvailabilityZone'])
    # Wait for instance to be in runnign state

    waiter = ec2client.get_waiter('instance_running')
    waiter.wait(InstanceIds=[response['Instances'][0]['InstanceId']])
    event['ForensicInstanceId'] = response['Instances'][0]['InstanceId']
    event['availabilityZone'] = response['Instances'][0]['Placement']['AvailabilityZone']
    event['SSM_STATUS'] ='WAIT'
    return event
