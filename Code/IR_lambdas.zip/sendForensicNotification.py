
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.


import boto3
import json
import logging
import os

from base64 import b64decode
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError

client = boto3.client('s3')

HOOK_URL = os.environ['HookUrl']
# The Slack channel to send a message to stored in the slackChannel environment variable
SLACK_CHANNEL = os.environ['SlackChannel']
forensic_output_s3_bucketname = os.environ['OUTPUT_S3_BUCKETNAME']
forensic_output_s3_bucketregion = os.environ['OUTPUT_S3_BUCKETREGION']
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    instanceID = event['instanceID']
    s3location = "https://s3.console.aws.amazon.com/s3/buckets/" + forensic_output_s3_bucketname + "/incident-response/" +  instanceID + "/?region=" + forensic_output_s3_bucketregion + "&tab=overview"
    slack_message_text = formatMyMessage(instanceID, s3location)
    req = Request(HOOK_URL, json.dumps(slack_message_text).encode('utf-8'))
    try:
        response = urlopen(req)
        response.read()
        logger.info("Message posted to %s", SLACK_CHANNEL)
    except HTTPError as e:
        logger.error("Request failed: %d %s", e.code, e.reason)
    except URLError as e:
        logger.error("Server connection failed: %s", e.reason)
 
    return event

def formatMyMessage(instanceID, s3location):
    slack_message = {
        "attachments": [
            {
                "fallback": "Required plain-text summary of the attachment.",
                "color": "#b7121a",
                "title": "Forensic analysis of instance : " +  instanceID + " is complete.",
                "text": "",
                "fields":[{
                        "value": "Both the sanpshot and memory forensic analysis of the instance have completed.\nThe data of the forensic analysis of instance " + instanceID + " are available in the S3 bucket:\n" + s3location
                    }]
            }
        ]
    }
    return slack_message