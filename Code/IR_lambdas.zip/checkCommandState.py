
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import logging
import json
# ssmclient = boto3.client('ssm')

logger = logging.getLogger()
logger.setLevel(logging.INFO)
ssmclient2 = boto3.client('ssm')

# Isolate the instance from the network
def lambda_handler(event, context):

    accountID = event['accountId']
    instanceID = event['instanceID']
    sts = boto3.client('sts')
    credentials = sts.assume_role(RoleArn='arn:aws:iam::'+ accountID +':role/Role_for_Nginx_Web_App_Instance', RoleSessionName = "RoleSession1")['Credentials']
    ACCESS_KEY = credentials['AccessKeyId']
    SECRET_KEY = credentials['SecretAccessKey']
    SESSION_TOKEN = credentials['SessionToken']

    ssmclient = boto3.client(
        'ssm',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
    )

    command_to_check = event.get('command_to_check')
    if (command_to_check == "MemoryDump"):
        instance_to_check = event.get('instanceID')
    elif (command_to_check == "SnapshotForensicAnalysis") or  (command_to_check == "MemoryForensicAnalysis"):
        instance_to_check = event.get('ForensicInstanceId')
    commandID = event.get('commandID')
    
    if (command_to_check == "SnapshotForensicAnalysis") or  (command_to_check == "MemoryForensicAnalysis"):
        response = ssmclient2.get_command_invocation(
        CommandId=commandID,
        InstanceId=instance_to_check
        )
    elif (command_to_check == "MemoryDump"):
        response = ssmclient.get_command_invocation(
        CommandId=commandID,
        InstanceId=instance_to_check
    )
    logger.info("Checking the status of the system manager command " + commandID)
    logger.info("The response of the get_command_invocation is: " + json.dumps(response))
    event['COMMAND_STATUS'] = response['Status']
    return event

