
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import logging


logger = logging.getLogger()
logger.setLevel(logging.INFO)

ec2client = boto3.client('ec2')

def lambda_handler(event, context):
    # TODO Create volume from the Snapshot ID passed in the event
    volumeresponse = ec2client.create_volume(
        AvailabilityZone=event.get('availabilityZone'),
        # response['Instances'][0]['Placement']['AvailabilityZone'],
        Size=100,
        SnapshotId=event.get('snapshotID'),
        TagSpecifications=[
            {
                'ResourceType': 'volume',
                'Tags': [
                    {
                        'Key': 'Name',
                        'Value': 'Isolated VOLUME'
                    },
                ]
            },
        ]
    )
    waiter = ec2client.get_waiter('volume_available')

    waiter.wait(
        VolumeIds=[
         volumeresponse['VolumeId']
        ]
    )
    response = ec2client.attach_volume(
        InstanceId=event.get('ForensicInstanceId'),
        VolumeId=volumeresponse['VolumeId'],
        Device='/dev/sdf'

    )
    logging.info(response)
    return event
