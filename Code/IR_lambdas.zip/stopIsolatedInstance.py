
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import logging
import json

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Isolate the instance from the network
def lambda_handler(event, context):
    accountID = event['accountId']
    instanceID = event['instanceID']
    sts = boto3.client('sts')
    credentials = sts.assume_role(RoleArn='arn:aws:iam::'+ accountID +':role/Role_for_Nginx_Web_App_Instance', RoleSessionName = "RoleSession1")['Credentials']
    ACCESS_KEY = credentials['AccessKeyId']
    SECRET_KEY = credentials['SecretAccessKey']
    SESSION_TOKEN = credentials['SessionToken']

    ssmclient = boto3.client(
        'ec2',
        aws_access_key_id=ACCESS_KEY,
        aws_secret_access_key=SECRET_KEY,
        aws_session_token=SESSION_TOKEN,
        )

    instanceID = event.get('instanceID')
    response = 'FAILED'
    response = ssmclient.stop_instances(
        InstanceIds=[
            instanceID,
        ],
        Force=True
    )
    logger.info("Response of the stop_instance API on instance " + instanceID + " : " + json.dumps(response))
    event['STATUS'] = 'SUCCEEDED'
    return event
# running