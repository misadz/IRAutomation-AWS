
# This sample, non-production-ready template describes an Amazon environment source code by cloudformation.
# © 2021 Amazon Web Services, Inc. or its affiliates. All Rights Reserved.
# This AWS Content is provided subject to the terms of the AWS Customer Agreement available at
# http://aws.amazon.com/agreement or other written agreement between Customer and either
# Amazon Web Services, Inc. or Amazon Web Services EMEA SARL or both.

import boto3
import os
import json
import logging
import uuid

logger = logging.getLogger()
logger.setLevel(logging.INFO)

forensic_step_function = os.environ['STEP_FUNCTION_ARN']

sfn = boto3.client('stepfunctions')

# Isolate the instance from the network
def lambda_handler(event, context):

    if event['detail']['resource']['resourceType'] == "Instance" :
        event_data={}
        event_type = event['detail-type']
        event_time = event['time']
        event_severity = event['detail']['severity']
        event_title = event['detail']['title']
        event_description = event['detail']['description']
        instanceID = event['detail']['resource']['instanceDetails']['instanceId']
        accountId = event['detail']['accountId']

        event_data['instanceID']=instanceID
        event_data['accountId']=accountId
        event_data['guard_duty_summary'] = {
                                    "event-type": event_type,
                                    "time": event_time,
                                    "severity": event_severity,
                                    "title": event_title,
                                    "description": event_description,                                
                                    }
        event_data['wait_time'] = 60
                                    
        logging.info("step function input:" + json.dumps(event_data))
        
        response = sfn.start_execution(
            stateMachineArn=forensic_step_function,
            name='IncidentResponse-For-'+accountId+"-"+instanceID+"-"+str(uuid.uuid4())[:4],
            input=json.dumps(event_data)
        )

        logging.info("step function response:" + str(response))

        output="Step Function successfully invoked"
    else:
        output="The GuardDuty finding was not about an instance. No incident remediation action was triggered."
        logging.info(output)
    return output
